/**
 * §E2E — PO Lifecycle tests.
 * Tests the full Vendor Central–style PO acknowledgment workflow.
 */
import { test, expect } from '@playwright/test';

async function loginAsBrand(page: any, name: string) {
  await page.goto('/');
  await page.click('text=Get Started');
  await page.waitForTimeout(500);
  await page.click('text=' + name);
  await page.waitForTimeout(800);
  await page.click('text=Purchase Orders');
  await page.waitForTimeout(800);
}

test.describe('PO Lifecycle', () => {
  test('1. Accept all lines → status updates, window appears', async ({ page }) => {
    await loginAsBrand(page, 'DeskForge Supplies Inc');
    const btn = page.locator('button', { hasText: 'Accept All' }).first();
    if (await btn.isVisible({ timeout: 3000 }).catch(() => false)) {
      await btn.click(); await page.waitForTimeout(500);
      await expect(page.locator('text=Accepted').first()).toBeVisible({ timeout: 5000 });
    } else test.fixme(true, 'No unacknowledged PO');
  });

  test('2. Reject some lines with reason code', async ({ page }) => {
    await loginAsBrand(page, 'DeskForge Supplies Inc');
    const exp = page.locator('button', { hasText: 'View Details' }).first();
    if (await exp.isVisible({ timeout: 3000 }).catch(() => false)) {
      await exp.click(); await page.waitForTimeout(500);
      const sel = page.locator('select').filter({ hasText: /Reject/i });
      if (await sel.isVisible({ timeout: 3000 }).catch(() => false)) {
        await sel.selectOption('rejected'); await page.waitForTimeout(300);
        const sub = page.locator('button', { hasText: 'Submit Acknowledgment' });
        if (await sub.isVisible().catch(() => false)) {
          await sub.click(); await page.waitForTimeout(500);
          await expect(page.locator('text=InvalidProductIdentifier').first()).toBeVisible({ timeout: 3000 });
        }
      }
    } else test.fixme(true, 'No PO detail');
  });

  test('3. Backorder lines → PO stays open', async ({ page }) => {
    await loginAsBrand(page, 'DeskForge Supplies Inc');
    const exp = page.locator('button', { hasText: 'View Details' }).first();
    if (await exp.isVisible({ timeout: 3000 }).catch(() => false)) {
      await exp.click(); await page.waitForTimeout(500);
      const sel = page.locator('select').first();
      if (await sel.isVisible().catch(() => false)) {
        await sel.selectOption('backordered'); await page.waitForTimeout(300);
        const sub = page.locator('button', { hasText: 'Submit Acknowledgment' });
        if (await sub.isVisible().catch(() => false)) {
          await sub.click(); await page.waitForTimeout(500);
          await expect(page.locator('text=Under Review').or(page.locator('text=Accepted')).first()).toBeVisible({ timeout: 5000 });
        }
      }
    } else test.fixme(true, 'No PO detail');
  });

  test('4. Partial ack (accept + reject + backorder) → each line independent', async ({ page }) => {
    await loginAsBrand(page, 'Nordhaus Living ApS');
    const exp = page.locator('button', { hasText: 'View Details' }).first();
    if (await exp.isVisible({ timeout: 3000 }).catch(() => false)) {
      await exp.click(); await page.waitForTimeout(500);
      const selects = page.locator('select');
      if ((await selects.count()) >= 2) {
        await selects.nth(0).selectOption('accepted');
        await selects.nth(1).selectOption('rejected');
        const sub = page.locator('button', { hasText: 'Submit Acknowledgment' });
        if (await sub.isVisible().catch(() => false)) {
          await sub.click(); await page.waitForTimeout(500);
          await expect(page.locator('text=Saved').or(page.locator('text=Acknowledgment')).first()).toBeVisible({ timeout: 3000 });
        }
      }
    } else test.fixme(true, 'No PO detail');
  });

  test('5. Ack qty exceeds ordered qty → blocked', async ({ page }) => {
    await loginAsBrand(page, 'DeskForge Supplies Inc');
    const exp = page.locator('button', { hasText: 'View Details' }).first();
    if (await exp.isVisible({ timeout: 3000 }).catch(() => false)) {
      await exp.click(); await page.waitForTimeout(500);
      const inp = page.locator('input[type="number"]').first();
      if (await inp.isVisible().catch(() => false)) {
        await inp.fill('99999'); await page.waitForTimeout(300);
        const sub = page.locator('button', { hasText: 'Submit Acknowledgment' });
        if (await sub.isVisible().catch(() => false)) {
          await sub.click(); await page.waitForTimeout(500);
          await expect(page.locator('text=exceed').or(page.locator('text=Error')).first()).toBeVisible({ timeout: 3000 });
        }
      }
    } else test.fixme(true, 'No PO detail');
  });

  test('6. 24-hour window expires → auto-flagged', async ({ page }) => {
    await loginAsBrand(page, 'Sahara Threads SARL');
    const el = page.locator('text=hour').or(page.locator('text=expired')).or(page.locator('text=deadline')).first();
    if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
      await expect(el).toBeVisible({ timeout: 2000 });
    } else test.fixme(true, 'No deadline displayed');
  });
});