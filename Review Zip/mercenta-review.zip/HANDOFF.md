---
# HANDOFF DOCUMENT — Mercenta Partners Platform Build
Last updated: September 5, 2026

## CONTEXT:
I'm building Mercenta Partners Ltd — a UK B2B wholesale distribution
platform that gets independent brands onto Amazon UK via our 1P
Vendor Central relationship. I'm using Cline to build it. The
platform is in DEMO MODE. Waiting on Amazon SP-API, DHL, Stripe,
and Companies House incorporation before going live.

## WHAT'S BUILT:
- Full React/TypeScript/Vite frontend (161 source files)
- Supabase backend (self-hosted) — 14 tables + RLS
- 20 Rakazo bots on DigitalOcean (all demo mode)
- 3 droplets: Supabase, Services, Rakazo
- Playwright test suite (54+ tests)
- Homepage: discreet "UK market" language (no Amazon mention)
- Partner Login + application gate + link verification
- Legal agreements 4.1 + 4.2 in onboarding
- 9 guided Usertours
- PO email notifications + auto-shipment + label/ASN stubs
- Penny Pincher bot (cost tracking, real API data, 7am)
- Margaret bot (UK accountant, 6:30am)
- Review zip script (bash scripts/export-review-zip.sh)

## WHAT'S LEFT (in order):
1. Xero integration (28-day reset, Supabase = source of truth)
2. Companies House + HMRC compliance dashboard
3. Rakazo iframe in Super Admin
4. Namecheap FTP deploy script
5. GO_LIVE.md playbook (13 items, all API keys)

## API KEYS I HAVE (in ~/Desktop/Mercenta/.env):
DigitalOcean, Postmark, Hunter.io, Firecrawl, PandaDoc,
OpenRouter, Instantly, Namecheap FTP

## API KEYS WAITING ON:
- Amazon SP-API — waiting on Amazon approval
- DHL Enterprise — waiting on DHL approval
- Stripe — waiting on Stripe approval
- Xero — sign up at developer.xero.com (free, can do now)
- Companies House API — sign up at
  developer.company-information.service.gov.uk (free, instant)
- Companies House Auth Code — comes by post after incorporation
- HMRC — sign up at developer.service.hmrc.gov.uk (few days)
- Keepa — paid ~$30/mo, get when ready

## KEY FILES:
- ~/Desktop/Mercenta/ — main project
- ~/Desktop/Mercenta/.env — all keys (gitignored)
- ~/Desktop/Mercenta/.clinerules/protection-rules.md — rules
- ~/Desktop/Mercenta/HANDOFF.md — THIS FILE
- ~/Desktop/Mercenta/scripts/export-review-zip.sh
- ~/Desktop/Rakazo/Mercenta Agents/ — bot registry + desktop app
- ~/Desktop/demo backup/ — exact demo files

## CLINE RULES (standing, apply to every task):
- Never change visual design (frozen)
- Never commit/push unless I say so
- Never delete demo data or demo accounts
- One task per chat, Act mode
- Commit before starting new work
- Before claiming done: run typecheck, build, relevant e2e tests,
  show git diff --stat, show test results, run zip script
- If I say "Provide Handoff": update HANDOFF.md with current state
- If a task is ambiguous, stop and ask
- If a change affects more than 5 files, stop and list them first

## DROPLETS:
- mercenta-supabase-demo (142.93.46.155, 2GB, London)
- mercenta-services (46.101.75.185, 4GB, London)
- mercenta-agents-v2 (24.144.86.50, 4GB, San Francisco)
SSH: ~/.ssh/id_ed25519 (Rakazo), ~/.ssh/mercenta_do_id_rsa (Services)

## BOTS (20, all demo mode):
Adam, Jess, Marcus, Priya, Kwame, Sofia, Elena, Diego (PAUSED),
Noor, Leo, Wei, Ava, Ravi, Freya, Omar, Ingrid, Zara (draft only),
Penny Pincher (7am), Margaret (6:30am), + 1 Chief

## BUSINESS:
- "UK Market-as-a-Service" (internal/diplomatic)
- Public site: "UK market" / "UK retail channels" ONLY
- NEVER: Amazon, Vendor Central, 1P, VaaS on public site
- 10 categories, African/Asian brand focus
- Embassy partnership angle

## COMPANY:
- Mercenta Partners Ltd — 1st Formations, waiting on ID verification
- Sole director/shareholder/PSC
- SIC: 46900, 46190, 62012, 52290
- Registered office: London. Residential: Harare, Zimbabwe

## CURRENT STATE:
- demo.mercenta.co.uk = frozen (Aug 31)
- Local code = current
- npm run preview = correct version
- Deploy script = NOT YET CREATED

## NEXT PROMPT TO PASTE:
[Prompt 3 — Xero Integration. See chat history or ask for it.]
---